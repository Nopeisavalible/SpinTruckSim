﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TruckRotation : MonoBehaviour 
{
	private AudioSource audioSource;

	private void Start()
	{
		audioSource = GetComponent<AudioSource>();
	}
	private void Update()
	{
		if (Input.GetKey (KeyCode.A)) 
		{
			Invoke ("MusicPlay", 0);
			transform.Rotate (0, 1, 0);
		} 
		if (Input.GetKey (KeyCode.D)) 
		{
			Invoke ("MusicPlay", 0);
			transform.Rotate (0, -1, 0);
		} 
		if (Input.GetKey (KeyCode.W)) 
		{
			Invoke ("MusicPlay", 0);
		transform.Rotate (1, 0, 0);
		}
		if (Input.GetKey (KeyCode.S)) 
		{
			Invoke ("MusicPlay", 0);
			transform.Rotate (-1, 0, 0);
		}
		if (Input.GetKey (KeyCode.E)) 
		{
			Invoke ("MusicPlay", 0);
			transform.Rotate (0, 0, -1);
		}
		if (Input.GetKey (KeyCode.Q)) 
		{
			Invoke ("MusicPlay", 0);
			transform.Rotate (0, 0, 1);
		}
	}
	bool music = false;
	private void MusicPlay() {
		if (Input.GetKey (KeyCode.E)||(Input.GetKey (KeyCode.Q))||(Input.GetKey (KeyCode.A))||(Input.GetKey (KeyCode.D))||(Input.GetKey (KeyCode.W))||(Input.GetKey (KeyCode.S))) {
			if (music == false) {
				music = true;
				Invoke("MyFunction", 0);
			}
		}
	}
	void MyFunction()
	{
		audioSource.Play ();
		Invoke ("Paause", 1);
	}
	void Paause()
	{
		audioSource.Pause();
		music = false;
	}

}	
